# Integration tests

Tests in this folder exercise the entire arXiv-search service against a
local instance of Elasticsearch.
