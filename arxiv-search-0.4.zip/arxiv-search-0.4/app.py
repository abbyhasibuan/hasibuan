"""Provides application for development purposes."""

from search.factory import create_ui_web_app

app = create_ui_web_app()
