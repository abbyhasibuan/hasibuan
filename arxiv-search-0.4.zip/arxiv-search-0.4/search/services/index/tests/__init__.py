"""Tests for :mod:`search.services.index`."""
