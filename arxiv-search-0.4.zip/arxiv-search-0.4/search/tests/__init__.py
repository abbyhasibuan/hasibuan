"""Tests for the application as a whole."""
