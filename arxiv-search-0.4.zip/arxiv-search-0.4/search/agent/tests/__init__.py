"""Tests for :mod:`search.agent`."""
