search.controllers.simple package
=================================

.. automodule:: search.controllers.simple
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

search.controllers.simple.forms module
--------------------------------------

.. automodule:: search.controllers.simple.forms
    :members:
    :undoc-members:
    :show-inheritance:


