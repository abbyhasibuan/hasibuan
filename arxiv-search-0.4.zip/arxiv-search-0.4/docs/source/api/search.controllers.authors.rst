search.controllers.authors package
==================================

.. automodule:: search.controllers.authors
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

search.controllers.authors.forms module
---------------------------------------

.. automodule:: search.controllers.authors.forms
    :members:
    :undoc-members:
    :show-inheritance:


