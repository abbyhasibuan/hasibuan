search.controllers package
==========================

.. automodule:: search.controllers
    :members:
    :undoc-members:
    :show-inheritance:

Subpackages
-----------

.. toctree::

    search.controllers.advanced
    search.controllers.authors
    search.controllers.simple

Submodules
----------

search.controllers.util module
------------------------------

.. automodule:: search.controllers.util
    :members:
    :undoc-members:
    :show-inheritance:


