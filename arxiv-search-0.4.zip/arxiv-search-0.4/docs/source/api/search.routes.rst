search.routes package
=====================

.. automodule:: search.routes
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

search.routes.ui module
-----------------------

.. automodule:: search.routes.ui
    :members:
    :undoc-members:
    :show-inheritance:


